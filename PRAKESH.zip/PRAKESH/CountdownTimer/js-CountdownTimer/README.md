## js-CountdownTimer

Click here to try it: https://rr-javascript-countdown-timer.netlify.app/

It a countdown timer web application using HTML, CSS, and JavaScript. This timer will allow users to set a specific date and time in the future, and then it will count down to that moment, displaying the remaining time in days, hours, minutes, and seconds.

https://github.com/rohitraj232/js-CountdownTimer/assets/57895889/cabd4f03-5866-4dcd-9557-ddbfcd7b29a1

