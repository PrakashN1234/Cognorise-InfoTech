|                               [Countdown Timer](https://youtu.be/7guNNC2QEKo "Click me!⌛") 🕔                               |
| :--------------------------------------------------------------------------------------------------------------------------: |
|                                                                                                                              |
|           You can view the project [**here**](https://isbendiyarovanezrin.github.io/CountdownTimer "Click me!⌛").           |
|                                                                                                                              |
|                                Countdown timer built with HTML5, CSS3 and vanilla JavaScript.                                |
|                                                                                                                              |
|                                                        Screenshot 📸                                                         |
|                                                                                                                              |
|                  !["Countdown timer" project screenshot](https://i.postimg.cc/xTVhr9yY/countdown-timer.png)                  |
|                                                                                                                              |
|                                                          License 📝                                                          |
|              Copyright © 2022 [**Nəzrin İsbəndiyarova**](https://github.com/isbendiyarovanezrin "Click me!😎").              |
| This project is [**MIT**](https://github.com/isbendiyarovanezrin/CountdownTimer/blob/master/LICENSE "Click me!🧐") licensed. |
|                                                                                                                              |
