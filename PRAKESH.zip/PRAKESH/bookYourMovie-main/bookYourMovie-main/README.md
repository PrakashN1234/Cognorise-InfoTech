<h1>Simple website for booking movie tickets </h1>

deployed 
<a href="https://ismailummer.github.io/bookYourMovie/">link </a> 

netlify hosted link :<a href="https://bookyourmovie1.netlify.app">link </a> 

login in :-
Username : admin
password : admin
