## BMI Calculator

BMI (body mass index) is a measure of whether you're a healthy weight for your height. Use this BMI calculator to check the adults in your family. Also convert Height from feet into Centimeter and weight from pound to Kg.

IT also has a responsive BMi Table to compare your results. It also include a Body fat calculator.

<img src="https://user-images.githubusercontent.com/87291732/210175611-e976afb8-ed9c-47ad-aeef-85e4a691c8d6.png" width="350" title="hover text"> 
<img src="https://user-images.githubusercontent.com/87291732/210175629-81f9b565-be4d-4138-bda0-121c9d8d6613.png" width="350" title="hover text"> 

### Demo: https://faisalkhan171101.github.io/BMICalculator.github.io/

© 2022 Faisal Khan, Presidency University
